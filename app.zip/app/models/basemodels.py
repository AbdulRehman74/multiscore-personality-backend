from pydantic import BaseModel

class SignupRequest(BaseModel):
    email: str
    password: str
    full_name: str

class VerifyOtpRequest(BaseModel):
    email: str
    otp: str

class LoginRequest(BaseModel):
    email: str
    password: str

class ForgotPasswordRequest(BaseModel):
    email: str

class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str

class SendOtpRequest(BaseModel):
    email: str

class SendResultRequest(BaseModel):
    email: str
    html_template: str